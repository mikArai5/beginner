function fn(number) {
  return number * 2;
}