import "./Child.css";

const Child = () => {
  return (
    <div className="component">
      <h3>式と文</h3>
    </div>
  );
};

export default Child;
