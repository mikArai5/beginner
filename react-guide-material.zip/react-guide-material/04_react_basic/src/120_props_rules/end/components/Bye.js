const Bye = (props) => {
  return (
    <div>
      <h3>Bye {props.name}</h3>
    </div>
  );
};

export default Bye;