import Child from "./components/Child";
import Expression from "./components/Expression";

const Example = () => {
  return (
    <div>
      <Child />
      <Expression />
    </div>
  );
};

export default Example;
