import { useState } from "react";

const Example = () => {
  const personObj = { name: "Tom", age: 18 };
};

export default Example;
