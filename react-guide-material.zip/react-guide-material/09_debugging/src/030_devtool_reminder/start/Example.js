const Example = () => {
  return (
    <>
      <h3>React Developer Toolsを使ってみよう</h3>
    </>
  );
};

export default Example;
